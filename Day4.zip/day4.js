function firstimage()
{
    const first=document.getElementById("firstimage");
    // console.log(first);
    url="ONE.jpg";
    first.src=url;
}
function changeimage()
{
    const second=document.getElementById("firstimage");
    // console.log(second);
    url2="TWO.jpg";
    second.src=url2;
}

function changeagain()
{
    const third=document.getElementById("firstimage");
    // console.log(third);
    url3="THREE.jpg";
    third.src=url3;
}

function copytext()
{
    const text=document.getElementById("enter");
    const ctext=document.getElementById("enter2");
    ctext.value=text.value;
}

let userlist = {
    user1 :{
    name: "Lily",
    age: 20,
    country: "India",
    hobbies:["Reading","Painting","Doodling"],
    },
    user2 :{
    name: "Sam",
    age: 25,
    country: "Australia",
    hobbies:["Reading","Painting","Doodling"],
    },
    user3 :{
    name: "Lucky",
    age: 30,
    country: "Canada",
    hobbies:["Reading","Painting","Doodling"],
    },
    user4 :{
    name: "Reema",
    age: 23,
    country: "India",
    hobbies:["Reading","Painting","Doodling"],
    }
             };
    let userage=[];     
    let usercountry=[];    

function display()
{
    console.log(userlist);
}  
display();  

console.log("Users with age less than 30");
function ageval()
{
    for (let users in userlist)
    {
        if(userlist[users].age<30)
        {
            console.log(userlist[users]);
        }
    }
}
ageval();

console.log("Users with Country India");

function countryval()
{
    for (let user in userlist)
    {
        if(userlist[user].country=="India")
        {
            console.log(userlist[user]);
        }
    }
}
countryval();